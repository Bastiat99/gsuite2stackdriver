#!/usr/bin/python 
import os
import audit.reports as reports

DOMAIN = os.environ['GCP_DOMAIN']
ORG = "organizations/{}".format(os.environ['GCP_ORG_ID'])
LOG_PROJECT = "projects/{}".format(os.environ['GCP_LOG_PROJECT'])

# Syncs GSuite login-activity report to Stackdriver
reports.sync_admin_logs('login', LOG_PROJECT, 'custom.auth.google.com%2flogins')
# Syncs GSuite Admins-activity report to Stackdriver
reports.sync_admin_logs('admin', LOG_PROJECT, 'custom.auth.google.com%2fadminactivity')
