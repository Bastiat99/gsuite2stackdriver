Utilities for manipulating IPv4 and IPv6 addresses including a
class that can be used to include CIDR network blocks in Django's
INTERNAL_IPS setting.

Full documentation at http://python-iptools.readthedocs.org/


