#!/bin/bash
set -x

export project_id=$(gcloud config get-value project)
export gcp2gsuite=gcp2gsuite

function create_service_account () {
gcloud iam service-accounts create  ${gcp2gsuite} --display-name "${gcp2gsuite}"
gcloud projects add-iam-policy-binding $project_id --member 'serviceAccount:'${gcp2gsuite}'@'${project_id}'.iam.gserviceaccount.com' --role 'roles/logging.admin' > /dev/null 2>&1
gcloud projects add-iam-policy-binding $project_id --member 'serviceAccount:'${gcp2gsuite}'@'${project_id}'.iam.gserviceaccount.com' --role 'roles/iam.serviceAccountTokenCreator' > /dev/null 2>&1
}

function domain_instructions () {
printf "Following these instructions to enable Gsuite Delegation for ${gcp2gsuite} account on ${project_id} \n \n  https://forsetisecurity.org/docs/v2.1/configure/inventory/gsuite.html \n \n"

printf "Required API scopes Admin Console: https://www.googleapis.com/auth/admin.directory.user.readonly,https://www.googleapis.com/auth/admin.reports.audit.readonly,https://www.googleapis.com/auth/admin.reports.usage.readonly,https://www.googleapis.com/auth/analytics.readonly \n \n"
}

create_service_account
domain_instructions
