#!/bin/bash
set -x

export project_id=$(gcloud config get-value project)
export gcp2gsuite=gcp2gsuite

function install_jq () {
sudo apt-get install --assume-yes jq 
}

function install_pip () {
sudo apt install python-pip
sudo pip install -r requirements.txt -t lib/
sudo pip install --upgrade oauth2client
sudo pip install iptools
sudo pip install python-dateutil
sudo pip install --upgrade google-api-python-client
}

function set_variables () {
export PROJECT_INFO=$(gcloud compute project-info describe --format=json)
export ADMIN_EMAIL=$(echo $PROJECT_INFO | jq -r '.commonInstanceMetadata.items[] | select(.key == "ADMIN_EMAIL") | .value')
export GCP_DOMAIN=$(echo $PROJECT_INFO | jq -r '.commonInstanceMetadata.items[] | select(.key == "GCP_DOMAIN") | .value')
export GCP_LOG_PROJECT=$(echo $PROJECT_INFO | jq -r '.commonInstanceMetadata.items[] | select(.key == "GCP_LOG_PROJECT") | .value')
export GCP_ORG_ID=$(echo $PROJECT_INFO | jq -r '.commonInstanceMetadata.items[] | select(.key == "GCP_ORG_ID") | .value')
export GCE_AUDIENCE=$(echo $PROJECT_INFO | jq -r '.commonInstanceMetadata.items[] | select(.key == "GCE_AUDIENCE") | .value')
}

function check_variables () {
if [  -z "$project_id" ]; then 
   printf "ERROR: GCP PROJECT_ID is not set.\n\n" 
   printf "To update project config: gcloud config set project PROJECT_ID \n\n" 
   exit
fi

if [  -z "$ADMIN_EMAIL" ]; then 
   printf "ERROR: ADMIN_EMAIL is not set in GCP project metadata.\n\n" 
   printf "To update ADMIN_EMAIL: gcloud compute project-info add-metadata --metadata ADMIN_EMAIL=your_super_user@your_domain_name .\n\n" 
   exit
fi

if [  -z "$GCP_DOMAIN" ]; then 
   printf "ERROR: GCP_DOMAIN is not set in GCP project metadata.\n\n" 
   printf "To update GCP_DOMAIN: gcloud compute project-info add-metadata --metadata GCP_DOMAIN=your_domain_name \n\n" 
   exit
fi

if [  -z "$GCP_LOG_PROJECT" ]; then 
   printf "ERROR: GCP_LOG_PROJECT is not set in GCP project metadata.\n\n" 
   printf "To update GCP_LOG_PROJECT: gcloud compute project-info add-metadata --metadata GCP_LOG_PROJECT=project_for_stackdriver_logging \n\n" 
   exit
fi 

if [  -z "$GCE_AUDIENCE" ]; then 
   printf "ERROR: GCP_AUDIENCE is not set in GCP project metadata.\n\n" 
   printf "To update GCP_AUDIENCE: gcloud compute project-info add-metadata --metadata GCP_AUDIENCE=http://your_domain_name \n\n" 
   exit
fi

if [  -z "$GCP_ORG_ID" ]; then 
   printf "ERROR: GCP_ORG_ID is not set in GCP project metadata.\n\n" 
   printf "To update GCP_ORG_ID: gcloud compute project-info add-metadata --metadata GCP_ORG_ID=your_organization_id \n\n" 
   exit
fi 
}

function enable_api () {
gcloud services list --enabled |grep ^admin.googleapis.com
RESULT=$?
if [ $RESULT -eq 0 ]; then
  echo "Admin API enabled"
  else
  gcloud services enable admin.googleapis.com
fi
}

function create_service_account () {
gcloud iam service-accounts create  ${gcp2gsuite} --display-name "${gcp2gsuite}"
gcloud projects add-iam-policy-binding $project_id --member 'serviceAccount:'${gcp2gsuite}'@'${project_id}'.iam.gserviceaccount.com' --role 'roles/logging.admin' > /dev/null 2>&1
gcloud projects add-iam-policy-binding $project_id --member 'serviceAccount:'${gcp2gsuite}'@'${project_id}'.iam.gserviceaccount.com' --role 'roles/iam.serviceAccountTokenCreator' > /dev/null 2>&1
}

function domain_instructions () {
printf "Following these instructions to enable Gsuite Delegation for ${gcp2gsuite} account on ${project_id} \n \n  https://forsetisecurity.org/docs/v2.1/configure/inventory/gsuite.html \n \n"

printf "Required API scopes Admin Console: https://www.googleapis.com/auth/admin.directory.user.readonly,https://www.googleapis.com/auth/admin.reports.audit.readonly,https://www.googleapis.com/auth/admin.reports.usage.readonly,https://www.googleapis.com/auth/analytics.readonly \n \n"
}

function enable_cronjob () {
CRON_PATH='/usr/local/bin'
CRON_SCRIPT="${CRON_PATH}/gsuite2stackdriver.sh"
CRON_JOBS="/tmp/jobs.txt"
LOGS_PATH="/var/log/cron"
CRON_LOGS="${LOGS_PATH}/cron.log"

# setup logging
sudo mkdir -p ${LOGS_PATH}
sudo touch ${CRON_LOGS}

# write script(s) for cron triggers - edit this script as required
script="
#!/bin/bash
export ADMIN_EMAIL=$ADMIN_EMAIL
export GCP_DOMAIN=$GCP_DOMAIN
export GCP_LOG_PROJECT=$GCP_LOG_PROJECT
export GCP_ORG_ID=$GCP_ORG_ID
export GCE_AUDIENCE=$GCE_AUDIENCE
python $PWD/gce_main.py
"
# NOTE: ${script} is wrapped in "" to preserve newlines on write
echo "${script}" |sudo tee ${CRON_SCRIPT}
sudo chmod +x ${CRON_SCRIPT}

# write cron triggers - edit CRON schedule as required
sudo echo "*/30 * * * * /bin/bash ${CRON_SCRIPT} >> ${CRON_LOGS} 2>&1" > ${CRON_JOBS}
sudo crontab ${CRON_JOBS}
}

install_jq
install_pip
set_variables
check_variables
enable_api
#create_service_account
#domain_instructions
enable_cronjob
